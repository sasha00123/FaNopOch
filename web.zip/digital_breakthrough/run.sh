cd services
cd web
export FLASK_APP=project/__init__.py
python manage.py run
input